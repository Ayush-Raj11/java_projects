package All_Java_Projects;

import java.io.SyncFailedException;
import java.util.Scanner;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class scanne_exampkle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the integer a");
		int a=obj.nextInt();
		
		System.out.println(a);
		System.out.println("Enter the String str");
		String string=obj.nextLine();
		System.out.println(a);
		

	}

}
