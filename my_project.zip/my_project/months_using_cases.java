

package my_project;

public class months_using_cases {

	public static void main(String[] args) {
		
		// ---- Switch Case to find how many days in "feb"  in a specific month ----
		
		String month = "feb";
		
		int year = 2022;
		
		switch (month) {
		
		case "jan" :
		case "march":
		case "may":
		case "july":
		case "Aug":
		case "Oct":
		case "Dec":
			System.out.println("31 Days");
			break;
			
		case "feb" :
			if (year%4==0 && year %100!=0 || year%400==0) {
				System.out.println("29 Days");
			}
			else {
			System.out.println("28 Days");
			}
			break;
			
		case "April":
		case "June":
		case "Sep":
		case "Nov":
			System.out.println("30 Days");
			break;	
		}
	}
}