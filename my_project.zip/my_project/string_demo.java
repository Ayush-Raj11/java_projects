package my_project;

public class string_demo {

	public static void main(String[] args) {
		String S1="Java is a language";   
		System.out.println(S1);
		String S2="hi";
		String S3="java program";
		String S4;
		
		System.out.println(S2);
		System.out.println(S1.concat(S2));
		System.out.println(S1+S2);
		System.out.println(S1.equalsIgnoreCase(S3));
		System.out.println(S1==S3);
		System.out.println(S1.charAt(3));
		System.out.println(S1.indexOf("is",4));
		System.out.println(S1.indexOf("java"));
		System.out.println(S1.lastIndexOf("java"));
		System.out.println(S1.substring(10,14));
		System.out.println(S1.toUpperCase());
		System.out.println(S4=S1.toUpperCase());
		System.out.println(S4.toLowerCase());
		System.out.println(S1.replace('a','e')); // for character.
		System.out.println(S1.replaceFirst("java","python"));
		System.out.println(S1.replaceAll("java","python"));
		
		
		
		
		
		
	}

}
