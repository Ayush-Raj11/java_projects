
package my_project;
public class relational_operators {

	public static void main(String[] args) {
	// relational operators 
		 // or(||)
		 // AND (||)
	int a=50;
	int b=60;
	System.out.println(a==b || a<b);
   }
}
