package my_project;

public class print_1_to_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// to print the values from 1 to 10.
		
		for(int i=0;i<=10;i++) { 
			
				 System.out.println(i);	
		}
	}

}
