package my_project;

public class fibonacci {

	public static void main(String[] args) {
		// To find the fibonacci series upto user want.

		int a=0,b=1,i=1;
		System.out.print(a + " ");
		while(i < 10) {
			System.out.print(b+" ");
			int next_value = a+b;
			a=b;
			b=next_value;
			i++;	
		}
		
		// 0 1 (0+1) (1+1) (2+1) (2+3)................
	}

}
