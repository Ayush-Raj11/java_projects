package my_project;

public class constructor_demo {
	// constructor_overloading
	// NOTE :- constructors can not be overwrite.
    constructor_demo(){
    	System.out.println("default const");
    }
constructor_demo(int a){
	System.out.println("int const");
    }
constructor_demo(int a,int b){
	System.out.println("2 para const");
}
    
	public static void main(String[] args) {
	
     constructor_demo obj1=new constructor_demo(10);
     constructor_demo obj2=new constructor_demo();
     constructor_demo obj3=new constructor_demo(10,10);
     
	}

}
// create two methods and overload both the method and override one method in child class.

