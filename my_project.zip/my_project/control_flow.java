package my_project;

public class control_flow {
	 public static void main(String[] args) {
		  
		  System.out.println("hello");
		  
		  // control flow
		  
		  int a=50;
		  if(a>0) {
			  System.out.println("a is greater than 0");
		  }
	  }
}
