package my_project;

public class grade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("Finding grade");
		
		int a=85;
		if(a>=80 && a<=90) {
			 System.out.println(" A grade");
		}
		
		if(a>=70 && a<=79) {
			 System.out.println(" B grade");
		}
		if(a>=60 && a<=69) {
			 System.out.println(" C grade");
		}
		if(a>=50 && a<=59) {
			 System.out.println(" D grade");
		}
	}

}
