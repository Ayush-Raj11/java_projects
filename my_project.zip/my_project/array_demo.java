package my_project;

import java.util.Arrays;

public class array_demo {

	public static void main(String[] args) {
		//ARRAY 10,20,30,.........
		int[] array1= {10,20,30,40};
		int[] sort1= {};
		double avg;
		int sum = 0;
		int len=array1.length;
		
//		  for(int i=0;i<len-1;i++) { if (i==2) { array1[i]=70; } sum=sum+array1[i]; }
//		  avg=sum/len;
//		 
// ...instead of using iteration we can do like that for getting values from Array. 

for (int values:array1 ) {

	System.out.println(sum=sum+values);;
}
avg=sum/len;
System.out.println(avg);
sort1 =Arrays.sort(array1);
	}
}


// 2d- Array

















// 3d array.












