package my_project;

import java.util.ArrayList;

public class arraylist_practice {
   
	

	public static void main(String[] args) {
	
      ArrayList<String>S1=new ArrayList<String>();
      S1.add("red");
      S1.add("blue");
      S1.add("yellow");
      S1.add("green");
      
      ArrayList<String>S2=new ArrayList<String>();
      S1.add("red");
      S1.add("blue");
      S1.add("Black");
      S1.add("White");
      
      ArrayList<String>S3=new ArrayList<String>();
      
      for(String elements:S1) {
    	  S3.add(S2.contains(element) ?"yes" :"no");
      }
      System.out.println(S3);
	}
}
