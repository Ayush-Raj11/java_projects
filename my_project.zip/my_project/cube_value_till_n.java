package my_project;

public class cube_value_till_n {

	public static void main(String[] args) {
       int  n=10;
       for(int i=1;i<=n;i++) {
    	   System.out.println(i*i*i);
       }
	}

}
