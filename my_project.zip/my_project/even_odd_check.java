package my_project;

public class even_odd_check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int a=21;
     if(a%2==0 ) {
    	 System.out.println("it is an even number");
     }
     else {
    	 System.out.println("it is a odd number");
     }
	}

}
