package my_project;

public class grade_using_switches {

	public static void main(String[] args) {
		
		// --------Switch Case----------
		
		int grade = 40;
		
//		char a = 'B';
		
		int cgpa = grade/10;
		
		switch (grade) {
		 	
//		case 'A':
//		case 'B':
		case 9:
		case 8:
			System.out.println("Grade A");
			break;
			
		case 7:
		case 6:
			System.out.println("Grade B");
			break;
			
		case 5:
		case 4:
			System.out.println("Grade c");
			break;
		
		
		default: 
			System.out.println("Fail");
		}
	}
}