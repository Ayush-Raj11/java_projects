

package my_project;
public class swap {

	public static void main(String[] args) {
	
	int a=20,b=35,temp=0;
	temp=a;
	a=b;
	b=temp;
	
	//without using third variable.
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("a="+a);
		System.out.println("b="+b);
   }
     
}
