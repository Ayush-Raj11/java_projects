package my_project;

public class factorial_of_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int n=4,fac=1;
    for(int i=1;i<=n;i++) {
    	
    	fac=fac*i;
    }
    System.out.println(fac);
	}

}
