package my_project;

public class greatest_among_3 {
	 public static void main(String[] args) {
		  
		  System.out.println("to check greatest among three numbers");
		  
		  int a=20,b=30,c=50;
		    if(a>b && a>c) {
		    
		    	 System.out.println("a is greater");
		    }
		    else if(b>a&& b>c) {
		    	 System.out.println("b is greater");
		    }
		    else{
		    	 System.out.println("c is greater");
		    }
		  
	  }
}
