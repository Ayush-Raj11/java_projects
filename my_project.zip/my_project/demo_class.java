package my_project;

public class demo_class {
  public static void main(String[] args) {
	  
	  System.out.println("hello");
	  int a=10,b=12,c=0,d=0;
	  c=++b;
	  System.out.println(b);
	  System.out.println(c);
	  d=b++;
	  System.out.println(b);
	  System.out.println(d);
  }
}
