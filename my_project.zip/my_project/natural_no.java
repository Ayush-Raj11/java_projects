


package my_project;

public class natural_no {

	public static void main(String[] args) {
		
		// ----for loop to find Natural Numbers----
		
		int num = 6;
		
		int var = 0;
		
		for(int i=1; i<=num; i++ ) {
			
			var += i;	
		}
		
		System.out.println(var);
	}
}