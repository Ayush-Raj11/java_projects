//package my_project;
//
//public class string_buffer_demo {
//
//	public static void main(String[] args) {
//		
//		// StringBuffer/String builder..(can be mutable)
//StringBuffer S1= new StringBuffer("hello");
//StringBuilder S2= new StringBuilder("hi");
//S1.append("class");
//System.out.println(S1.replace(5, 10, "everyone"));
//System.out.println(S1.delete(5, 13));
//System.out.println(S1.insert(5, "java"));
////System.out.println(S1.reverse());
//S1.setCharAt(0, 'm');
//System.out.println(S1);
//String S3=S2.toString();
//	}
//
//}

            // ....((HANDS-ON)).... //
//..(to calculate the total no of characters in the string)..

//package my_project;
//public class string_buffer_demo {
//	public static void main(String[] args) {
//		String S1= "prithviraj";
//		int count=0 ;
//		for(int i=0;i<= S1.length()-1;i++) {
//			count=count+1;
//		}
//		System.out.println(count);
//	}
//}
//
//



// ..(To check the occurance of specific alpha in a given string)..
package my_project;
public class string_buffer_demo {

	public static void main(String[] args) {
		
		String S1= "prithviraj";
		int count=0;
				for(int i=0;i<= S1.length()-1;i++) {
					if(S1.charAt(i)=='i') {
						count++;
					}
				
				}
				System.out.println("no of 'i' in string = "+count);
	}
	

}

