package my_project;

public class multiplication_table {
	
	  public static void main(String[] args) {
		  
		  System.out.println("hello");
		  int n=22;
		  for(int i=1;i<=15;i++)
			  System.out.println(n*i);  
	  }
		 
}
