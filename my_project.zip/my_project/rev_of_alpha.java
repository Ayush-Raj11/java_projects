//package my_project;
//
//public class rev_of_alpha {
//
//	public static void main(String[] args) {
//	 // to find the reverse of alphabets using loop.
//     for(char i='Z'; i >='a';i--) {
//    	  System.out.println(i +" ");
//     }
//	}
//}


// REVERSE OF ALPHABETS
public class rev_of_alpha {
    public static void main(String[] args) {
        for (char i = 'z'; i >= 'a'; i--) {
            System.out.print(i + " ");
        }
    }
}