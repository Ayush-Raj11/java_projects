package my_project;

public class string_reverse {

	public static void main(String[] args) {
		// To check weather the no is palindrome or not..?
		
       String S1 ="Java is a program.";
       String Rev = "";
       String S2="shrivastav";
       
       for(int i=S1.length()-1;i>=0;i--) {
    	   
    	  Rev= Rev+S1.charAt(i); 
    	   
       }
       System.out.println(Rev);
       if(S1.equalsIgnoreCase(Rev)) {
    	   System.out.println("It is Palindrome.");
       }
       else {
    	   System.out.println("It is not a Palindrome."); 
       }
       System.out.println(S1.concat(S2));
	   System.out.println(S1.toUpperCase()+" "+S2.toUpperCase());
	   
	}


}



